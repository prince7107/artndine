function Footer() {
  return (
    <footer className="footer">
      <div className="wrap">
        <div className="footer-top">
          <div className="footer-brand">
            <h3>Art &amp; Dine</h3>
            <p>A travelling art studio for slow afternoons in Ghaziabad. Beginner-friendly workshops in the city's coziest cafes.</p>
            <form className="footer-newsletter" onSubmit={(e) => { e.preventDefault(); alert('Thanks — we\'ll send the next workshop your way.'); }}>
              <input type="email" placeholder="your email · softly" required />
              <button type="submit">Subscribe</button>
            </form>
          </div>
          <div className="footer-col">
            <h5>Workshops</h5>
            <ul>
              <li><a href="workshops.html">All workshops</a></li>
              <li><a href="#categories">Tote painting</a></li>
              <li><a href="#categories">Canvas art</a></li>
              <li><a href="#categories">Journal making</a></li>
              <li><a href="#upcoming">Upcoming dates</a></li>
            </ul>
          </div>
          <div className="footer-col">
            <h5>Studio</h5>
            <ul>
              <li><a href="#story">Our story</a></li>
              <li><a href="#gallery">Gallery</a></li>
              <li><a href="#">Corporate workshops</a></li>
              <li><a href="#">College workshops</a></li>
              <li><a href="#">Gift a workshop</a></li>
            </ul>
          </div>
          <div className="footer-col">
            <h5>Reach us</h5>
            <ul>
              <li><a href="https://www.instagram.com/artndinegzb">@artndinegzb</a></li>
              <li><a href="mailto:hello@artndine.in">hello@artndine.in</a></li>
              <li><a href="#">WhatsApp</a></li>
              <li><a href="#faq">FAQ</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <div>© 2026 Art &amp; Dine · Ghaziabad, India</div>
          <div className="footer-bottom-scribble">made with slow hands ✿</div>
          <div style={{display:'flex', gap:20}}>
            <a href="#">Privacy</a>
            <a href="#">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
window.Footer = Footer;
