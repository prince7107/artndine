function FAQ() {
  const [open, setOpen] = React.useState(0);
  const items = [
    {
      q: "Do I need any art experience?",
      a: "Not at all — most of our guests haven't painted since school. Every workshop is structured for absolute beginners, with a host who walks you through each step. If you can hold a brush, you're set."
    },
    {
      q: "What's included in the price?",
      a: "All materials (canvas/tote/paints/brushes), a full walkthrough by our host, and the finished piece to take home. A cup of chai or coffee is usually included at the host cafe — beyond that, food and drinks are on you."
    },
    {
      q: "Where exactly are the workshops held?",
      a: "We're a travelling studio — we partner with cozy cafes across Ghaziabad (Raj Nagar, Kavi Nagar, Vaishali, Indirapuram). Each event listing shows the exact cafe. You'll also get the address in your confirmation email."
    },
    {
      q: "Can I book a private or corporate workshop?",
      a: "Yes — we host corporate off-sites, college fests, birthdays, and hen parties (10–40 people). Reach out on WhatsApp with your group size and a rough date, and we'll design something for you."
    },
    {
      q: "What's your cancellation policy?",
      a: "Free reschedule up to 48 hours before the workshop. Refunds are available up to 72 hours prior. Within 48 hours we can transfer your seat to a friend, or issue a credit note valid for 3 months."
    },
    {
      q: "How many people are in one workshop?",
      a: "Small on purpose — usually 6 to 12 people per session. Small tables mean our host can actually help you when you get stuck, and the room stays calm."
    },
    {
      q: "Can I come alone?",
      a: "Please do. About half our guests come solo. You'll probably leave with a couple of new friends and a very soft afternoon."
    },
  ];

  return (
    <section id="faq" className="faq wrap">
      <div className="faq-grid">
        <div className="faq-side reveal">
          <div className="eyebrow">FAQ</div>
          <h2 style={{marginTop:16}}>
            Questions,<br/>
            <em style={{fontStyle:'italic', color:'var(--sage)'}}>gently answered.</em>
          </h2>
          <p>
            Everything you might want to know before booking. Still uncertain? We're a message away.
          </p>
          <div className="faq-help">
            <h4>Can't find your answer?</h4>
            <p>Send us a note on WhatsApp or Instagram — we usually reply within a couple of hours.</p>
            <a href="#contact">Get in touch →</a>
          </div>
        </div>

        <div className="faq-list reveal reveal-delay-1">
          {items.map((it, i) => (
            <div key={i} className="faq-item" data-open={open === i}>
              <button className="faq-q" onClick={() => setOpen(open === i ? -1 : i)}>
                <span>{it.q}</span>
                <span className="faq-icon">
                  <Icon name="plus" size={14} stroke={2} />
                </span>
              </button>
              <div className="faq-a"><p>{it.a}</p></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
window.FAQ = FAQ;
