// Icons — simple stroke SVG set. Exported to window.
const Icon = ({ name, size = 20, stroke = 1.6, style }) => {
  const props = {
    width: size, height: size, viewBox: "0 0 24 24",
    fill: "none", stroke: "currentColor",
    strokeWidth: stroke, strokeLinecap: "round", strokeLinejoin: "round",
    style
  };
  const paths = {
    arrow: <><path d="M5 12h14"/><path d="M13 5l7 7-7 7"/></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    location: <><path d="M12 21s7-6.5 7-12a7 7 0 10-14 0c0 5.5 7 12 7 12z"/><circle cx="12" cy="9" r="2.5"/></>,
    users: <><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.5-3.5 3.5-5.5 6.5-5.5s6 2 6.5 5.5"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c2.5 0 4.5 1.5 5 4"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></>,
    phone: <><path d="M22 16.9v3a2 2 0 01-2.2 2 19.8 19.8 0 01-8.6-3.1 19.5 19.5 0 01-6-6A19.8 19.8 0 012.1 4.2 2 2 0 014.1 2h3a2 2 0 012 1.7 12.8 12.8 0 00.7 2.8 2 2 0 01-.5 2.1L8 9.9a16 16 0 006 6l1.3-1.3a2 2 0 012.1-.5c.9.3 1.8.5 2.8.7a2 2 0 011.8 2z"/></>,
    instagram: <><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="0.6" fill="currentColor"/></>,
    whatsapp: <><path d="M20 12a8 8 0 11-14.9 4L4 20l4-1a8 8 0 0012-7z"/><path d="M9 10c0-.5.5-1 1-1s.5.3.8.9c.3.6.5 1 .3 1.3-.2.3-.4.4-.4.6 0 .3 1.3 1.7 2 2 .2 0 .3-.2.6-.4.3-.2.7 0 1.3.3.6.3.9.3.9.8s-.5 1-1 1c-2.5 0-5.5-3-5.5-5.5z"/></>,
    sparkle: <><path d="M12 3l1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5L12 3z"/></>,
    leaf: <><path d="M4 20c8 0 16-4 16-16-8 0-16 4-16 16z"/><path d="M4 20L16 8"/></>,
    palette: <><path d="M12 22a10 10 0 110-20 8 8 0 018 8c0 2-1 3-3 3h-2a2 2 0 00-2 2v2c0 2-1 5-3 5z"/><circle cx="7" cy="10" r="1.2"/><circle cx="10" cy="6" r="1.2"/><circle cx="15" cy="6" r="1.2"/><circle cx="18" cy="10" r="1.2"/></>,
    scissors: <><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4L8.5 15.5M20 20L8.5 8.5"/></>,
    book: <><path d="M4 4h7a3 3 0 013 3v14a2 2 0 00-2-2H4V4z"/><path d="M20 4h-7a3 3 0 00-3 3v14a2 2 0 012-2h8V4z"/></>,
    heart: <><path d="M12 20s-7-4.5-9-9a5 5 0 019-3 5 5 0 019 3c-2 4.5-9 9-9 9z"/></>,
    star: <><path d="M12 2l3 6.5 7 .8-5 4.9 1.3 7L12 17.7 5.7 21.2 7 14.2l-5-4.9 7-.8L12 2z"/></>,
    tag: <><path d="M20 12l-8 8-9-9V3h8l9 9z"/><circle cx="7" cy="7" r="1.4"/></>,
    grid: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
    scroll: <><path d="M6 4h12a2 2 0 012 2v13a3 3 0 01-3 3H8a3 3 0 01-3-3V6a2 2 0 011-1.7"/><path d="M8 10h8M8 14h5"/></>,
  };
  return <svg {...props}>{paths[name]}</svg>;
};

window.Icon = Icon;
