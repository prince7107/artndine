function Story() {
  return (
    <section id="story" className="story">
      <div className="wrap">
        <div className="story-grid">
          <div className="story-image-wrap reveal">
            <span className="story-image-scribble">since 2022 ✿</span>
            <img className="story-image" src="assets/img/story-studio.jpg" alt="Art & Dine studio corner" />
            <div className="story-image-tag">
              A tiny studio that <em>travels</em> — we pop up in Ghaziabad's coziest cafes.
            </div>
          </div>

          <div className="story-body reveal reveal-delay-1">
            <div className="eyebrow">Our story</div>
            <h2>
              We started because painting <em>felt like breathing</em>, and we wanted to share it.
            </h2>
            <p>
              Art &amp; Dine began at a small round table in a Ghaziabad cafe with three friends, two totes, and a very messy paint palette. What started as an afternoon-off turned into something quieter, softer — a small ritual we couldn't stop doing.
            </p>
            <p>
              Today we host cozy, beginner-friendly workshops across cafes in the city. No experience needed. No pressure to make something perfect. Just a couple of hours, warm light, good chai, and a small handmade thing you get to take home.
            </p>

            <div className="story-values">
              <div className="story-value">
                <h4>Slow by design</h4>
                <p>Two-hour sessions, small tables, no rush.</p>
              </div>
              <div className="story-value">
                <h4>Beginner-first</h4>
                <p>Zero art background? Perfect. That's who we plan for.</p>
              </div>
              <div className="story-value">
                <h4>Made to keep</h4>
                <p>Every workshop leaves you with something you made.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
window.Story = Story;
