function Testimonials() {
  const items = [
    {
      q: "I hadn't picked up a paintbrush in fifteen years. Left with a tote I still use every week and a very calm feeling I didn't know I needed.",
      name: "Ananya S.",
      meta: "Tote painting · March"
    },
    {
      q: "Booked it as a birthday thing for my best friend. We made the messiest, prettiest journals. The host was so gentle about it.",
      name: "Rhea K.",
      meta: "Journal making · June"
    },
    {
      q: "Corporate off-site with 14 people. Honestly better than any team lunch we've done. Everyone actually put their phones away.",
      name: "Aditya M.",
      meta: "Team workshop · May"
    },
  ];
  return (
    <section className="testimonials wrap">
      <div className="section-head-single reveal">
        <div className="eyebrow no-line" style={{justifyContent:'center'}}>Kind words</div>
        <h2 className="section-title" style={{marginTop:16}}>
          What people leave <em>saying.</em>
        </h2>
      </div>
      <div className="testi-grid">
        {items.map((t, i) => (
          <div key={i} className={`testi-card reveal reveal-delay-${i + 1}`}>
            <p className="testi-quote">{t.q}</p>
            <div className="testi-author">
              <div className="testi-avatar">{t.name[0]}</div>
              <div>
                <div className="testi-name">{t.name}</div>
                <div className="testi-meta">{t.meta}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
window.Testimonials = Testimonials;
