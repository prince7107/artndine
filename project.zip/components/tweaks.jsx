// Tweaks panel — palette + font + hero layout
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": "sage",
  "font": "fraunces",
  "hero": "collage"
}/*EDITMODE-END*/;

function ArtDineTweaks() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply tweaks to <body>
  React.useEffect(() => {
    document.body.setAttribute('data-palette', t.palette);
    document.body.setAttribute('data-font', t.font);
    document.body.setAttribute('data-hero', t.hero);
  }, [t.palette, t.font, t.hero]);

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection title="Palette">
        <TweakRadio
          label="Feel"
          value={t.palette}
          options={[
            { value: 'sage', label: 'Sage' },
            { value: 'cream-forward', label: 'Cream' },
            { value: 'terracotta', label: 'Terracotta' },
          ]}
          onChange={(v) => setTweak('palette', v)}
        />
      </TweakSection>

      <TweakSection title="Typography">
        <TweakSelect
          label="Serif for headings"
          value={t.font}
          options={[
            { value: 'fraunces', label: 'Fraunces' },
            { value: 'dm-serif', label: 'DM Serif Display' },
            { value: 'cormorant', label: 'Cormorant Garamond' },
            { value: 'playfair', label: 'Playfair Display' },
          ]}
          onChange={(v) => setTweak('font', v)}
        />
      </TweakSection>

      <TweakSection title="Hero layout">
        <TweakRadio
          label="Composition"
          value={t.hero}
          options={[
            { value: 'collage', label: 'Collage' },
            { value: 'organic-blob', label: 'Blob' },
            { value: 'full-bleed', label: 'Centered' },
          ]}
          onChange={(v) => setTweak('hero', v)}
        />
      </TweakSection>

      <TweakSuggestionBar suggestions={[
        "Make the sage a touch deeper",
        "Try Cormorant on the hero title only",
        "Reduce polaroid tilt",
        "Add a second CTA color",
      ]} />
    </TweaksPanel>
  );
}
window.ArtDineTweaks = ArtDineTweaks;
