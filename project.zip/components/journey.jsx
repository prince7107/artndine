function Journey() {
  const steps = [
    { n: "01", t: "Book your seat", d: "Pick a workshop and a date. Small tables, usually 6–10 people." },
    { n: "02", t: "Arrive & sip", d: "Walk in, find your spot, order a chai. We handle every material." },
    { n: "03", t: "Create together", d: "Our host walks you through it step by step. Zero experience needed." },
    { n: "04", t: "Take it home", d: "Leave with something you made — plus a soft, unhurried afternoon." },
  ];
  return (
    <section className="journey">
      <div className="wrap">
        <div className="section-head-single reveal">
          <div className="eyebrow no-line" style={{justifyContent:'center'}}>The afternoon</div>
          <h2 className="section-title" style={{marginTop:16}}>
            How a workshop <em>actually feels.</em>
          </h2>
          <p className="section-lede">
            Nothing complicated. Show up, we take care of the rest.
          </p>
        </div>

        <div className="journey-steps">
          {steps.map((s, i) => (
            <div key={s.n} className={`journey-step reveal reveal-delay-${i + 1}`}>
              <div className="journey-num">{s.n}</div>
              <h3>{s.t}</h3>
              <p>{s.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
window.Journey = Journey;
