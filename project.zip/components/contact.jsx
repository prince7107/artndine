function Contact() {
  const methods = [
    { icon: "instagram", label: "Instagram · DMs open", value: "@artndinegzb", href: "https://www.instagram.com/artndinegzb" },
    { icon: "whatsapp", label: "WhatsApp", value: "+91 98xxx xxxxx", href: "#" },
    { icon: "mail", label: "Email", value: "hello@artndine.in", href: "mailto:hello@artndine.in" },
  ];
  return (
    <section id="contact" className="contact">
      <div className="wrap">
        <div className="contact-grid">
          <div className="contact-side reveal">
            <div className="eyebrow">Say hello</div>
            <h2 style={{marginTop:16}}>
              Come find <em style={{fontStyle:'italic', color:'var(--sage)'}}>us.</em>
            </h2>
            <p className="section-lede" style={{marginBottom:36}}>
              Based in Ghaziabad — but the cafe changes with the workshop. Ping us and we'll point you to the next one closest to you.
            </p>
            <div className="contact-methods">
              {methods.map(m => (
                <a key={m.label} href={m.href} className="contact-method">
                  <span className="contact-icon"><Icon name={m.icon} size={20} /></span>
                  <div>
                    <div className="contact-method-label">{m.label}</div>
                    <div className="contact-method-value">{m.value}</div>
                  </div>
                </a>
              ))}
            </div>
          </div>

          <div className="contact-map reveal reveal-delay-1">
            <div className="contact-map-inner">
              {/* Faux map — simple road grid + parks */}
              <svg viewBox="0 0 400 500" preserveAspectRatio="xMidYMid slice">
                {/* soft blocks (parks) */}
                <rect x="30" y="60" width="120" height="90" rx="8" fill="oklch(0.85 0.05 155 / 0.4)"/>
                <rect x="250" y="300" width="120" height="140" rx="8" fill="oklch(0.85 0.05 155 / 0.4)"/>
                <rect x="200" y="80" width="60" height="60" rx="8" fill="oklch(0.86 0.04 155 / 0.35)"/>
                <rect x="60" y="340" width="80" height="70" rx="6" fill="oklch(0.86 0.04 155 / 0.35)"/>
                {/* roads */}
                <path d="M0 200 H400" stroke="oklch(0.98 0.01 82 / 0.8)" strokeWidth="14"/>
                <path d="M0 250 H400" stroke="oklch(0.98 0.01 82 / 0.4)" strokeWidth="6"/>
                <path d="M180 0 V500" stroke="oklch(0.98 0.01 82 / 0.8)" strokeWidth="14"/>
                <path d="M220 0 V500" stroke="oklch(0.98 0.01 82 / 0.4)" strokeWidth="6"/>
                <path d="M0 380 H400" stroke="oklch(0.98 0.01 82 / 0.6)" strokeWidth="10"/>
                <path d="M320 0 V500" stroke="oklch(0.98 0.01 82 / 0.6)" strokeWidth="10"/>
                {/* dashed rail */}
                <path d="M40 60 L 40 500" stroke="oklch(0.5 0.03 155 / 0.4)" strokeWidth="1.5" strokeDasharray="6 6"/>
                {/* tiny buildings */}
                {[...Array(30)].map((_, i) => {
                  const x = (i * 47) % 400;
                  const y = (i * 83) % 500;
                  return <rect key={i} x={x} y={y} width="6" height="6" fill="oklch(0.75 0.02 82 / 0.35)"/>;
                })}
              </svg>
              <div className="contact-map-pin">
                <div className="contact-map-pin-dot" />
                <div className="contact-map-label">Raj Nagar · Ghaziabad</div>
              </div>
              <div className="contact-map-note">
                <strong>Cafe varies by workshop</strong>
                Exact address goes out with your booking confirmation.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
window.Contact = Contact;
