function WorkshopsPage() {
  const [filter, setFilter] = React.useState('All');
  const [booking, setBooking] = React.useState(null);
  const [submitted, setSubmitted] = React.useState(false);

  const workshops = [
    {
      cat: "Painting", title: "Tote Bag Painting", price: 899, dur: "2 hrs",
      desc: "Hand-paint a canvas tote with botanicals or your own designs. Our most-loved starter workshop.",
      included: ["Canvas tote", "Acrylic paints & brushes", "Botanical stencils", "Chai on the house"],
      img: "assets/img/hero-tote.jpg", tag: "Best seller",
    },
    {
      cat: "Painting", title: "Cap Painting", price: 749, dur: "1.5 hrs",
      desc: "Turn a plain cotton cap into a small wearable painting. Great for gifting.",
      included: ["Cotton cap", "Fabric paints", "Design references", "Chai on the house"],
      img: "assets/img/hero-cap.jpg", tag: "New",
    },
    {
      cat: "Painting", title: "Watercolor Canvas Art", price: 999, dur: "2.5 hrs",
      desc: "Simple watercolor botanicals on a small stretched canvas. Framed and ready to hang.",
      included: ["8×10 stretched canvas", "Watercolor set", "Framing", "Chai on the house"],
      img: "assets/img/cat-canvas.jpg", tag: "Popular",
    },
    {
      cat: "Craft", title: "Journal Making", price: 1199, dur: "3 hrs",
      desc: "Bind your own softcover journal with pressed flowers and hand-lettered covers.",
      included: ["50-page inner block", "Book board & fabric", "Pressed flowers", "Chai on the house"],
      img: "assets/img/cat-journal.jpg", tag: "Slow craft",
    },
    {
      cat: "Craft", title: "Badge & Pin Making", price: 599, dur: "1.5 hrs",
      desc: "Illustrate, cut, press. Take home six original badges — no drawing skill needed.",
      included: ["6 badge blanks", "Illustration prompts", "Pin press access", "Chai on the house"],
      img: "assets/img/hero-badges.jpg", tag: "Beginner",
    },
    {
      cat: "Craft", title: "Wooden Bookmarks", price: 499, dur: "1 hr",
      desc: "Small hand-painted wooden bookmarks with dried florals. A gentle first workshop.",
      included: ["3 wooden blanks", "Paints & fine brushes", "Dried florals", "Chai on the house"],
      img: "assets/img/gal-bookmark.jpg", tag: "Quick session",
    },
    {
      cat: "Group", title: "Corporate Team Workshop", price: 899, dur: "2.5 hrs",
      desc: "Private on-site or in-cafe sessions for teams of 10–40. We bring the studio to you.",
      included: ["All materials", "Dedicated host", "Team activity prompts", "Group photo"],
      img: "assets/img/gal-group.jpg", tag: "Private",
    },
    {
      cat: "Group", title: "College & Fest Workshops", price: 599, dur: "2 hrs",
      desc: "Bulk-friendly workshops for college fests, hostels, and student groups. From 15 people.",
      included: ["All materials", "Dedicated host", "Custom theme", "Group discount"],
      img: "assets/img/gal-tote.jpg", tag: "Private",
    },
    {
      cat: "Seasonal", title: "Independence Day Special", price: 749, dur: "1.5 hrs",
      desc: "Themed cap and tote workshops for 15th August week. Tricolor botanicals.",
      included: ["Themed tote OR cap", "Seasonal colors", "Design pack", "Chai on the house"],
      img: "assets/img/gal-palette.jpg", tag: "August only",
    },
    {
      cat: "Seasonal", title: "Diwali Diya Painting", price: 649, dur: "1.5 hrs",
      desc: "Paint a set of six terracotta diyas with traditional or modern motifs.",
      included: ["6 terracotta diyas", "Paints & gold leaf", "Design pack", "Chai on the house"],
      img: "assets/img/gal-pins.jpg", tag: "Coming Oct",
    },
  ];

  const cats = ['All', 'Painting', 'Craft', 'Group', 'Seasonal'];
  const filtered = filter === 'All' ? workshops : workshops.filter(w => w.cat === filter);

  const openBook = (w) => { setBooking(w); setSubmitted(false); };
  const closeBook = () => setBooking(null);
  const submit = (e) => { e.preventDefault(); setSubmitted(true); };

  React.useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') closeBook(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <main>
      <section className="wk-hero wrap">
        <span className="wk-hero-scribble wk-hero-scribble-1">beginner-friendly ✿</span>
        <span className="wk-hero-scribble wk-hero-scribble-2">no experience needed</span>
        <div className="eyebrow wk-hero-eyebrow">All workshops</div>
        <h1>
          Ten quiet ways<br/>
          to spend an <em>afternoon.</em>
        </h1>
        <p>
          Every workshop is designed for absolute beginners. Come alone, bring a friend, or book a whole table. We provide every material — you just bring yourself and maybe a favorite playlist.
        </p>
      </section>

      <div className="wrap">
        <div className="wk-filters">
          {cats.map(c => (
            <button
              key={c}
              className="wk-filter"
              data-active={filter === c}
              onClick={() => setFilter(c)}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="wk-grid">
          {filtered.map((w, i) => (
            <div key={w.title} className="wk-item">
              <div className="wk-item-media">
                <img src={w.img} alt={w.title} loading="lazy" />
              </div>
              <div className="wk-item-body">
                <span className="wk-item-tag">{w.tag}</span>
                <h3>{w.title}</h3>
                <p className="wk-item-desc">{w.desc}</p>
                <ul className="wk-item-included">
                  {w.included.slice(0, 3).map(it => <li key={it}>{it}</li>)}
                </ul>
                <div className="wk-item-foot">
                  <div className="wk-item-price">
                    ₹{w.price.toLocaleString('en-IN')}
                    <small> · {w.dur}</small>
                  </div>
                  <button className="wk-item-book" onClick={() => openBook(w)}>
                    Book
                    <Icon name="arrow" size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Booking modal */}
      <div className="wk-modal-scrim" data-open={!!booking} onClick={closeBook}>
        <div className="wk-modal" style={{position:'relative'}} onClick={(e)=>e.stopPropagation()}>
          <button className="wk-modal-close" onClick={closeBook}>
            <Icon name="plus" size={14} stroke={2} style={{transform:'rotate(45deg)'}} />
          </button>
          {booking && !submitted && (
            <>
              <div className="eyebrow" style={{marginBottom:14}}>Reserve a seat</div>
              <h3>{booking.title}</h3>
              <p className="wk-modal-sub">
                Two-hour workshop · Materials, chai and a host included. Cafe address goes out on confirmation.
              </p>

              <form onSubmit={submit}>
                <div className="wk-form-row">
                  <label>Your name</label>
                  <input type="text" placeholder="Anaisha Kapoor" required />
                </div>
                <div className="wk-form-2col">
                  <div className="wk-form-row">
                    <label>Phone</label>
                    <input type="tel" placeholder="+91 98xxx xxxxx" required />
                  </div>
                  <div className="wk-form-row">
                    <label>Seats</label>
                    <select defaultValue="1">
                      <option>1 seat</option>
                      <option>2 seats</option>
                      <option>3 seats</option>
                      <option>4 seats</option>
                    </select>
                  </div>
                </div>
                <div className="wk-form-row">
                  <label>Preferred date</label>
                  <select defaultValue="">
                    <option value="" disabled>Pick a weekend</option>
                    <option>Sunday, 3 Aug · 3:00 PM</option>
                    <option>Sunday, 10 Aug · 4:00 PM</option>
                    <option>Sunday, 17 Aug · 2:30 PM</option>
                    <option>Sunday, 24 Aug · 4:00 PM</option>
                  </select>
                </div>

                <div className="wk-summary">
                  <span className="wk-summary-label">Total</span>
                  <span className="wk-summary-price">₹{booking.price.toLocaleString('en-IN')}</span>
                </div>

                <div className="wk-modal-actions">
                  <button type="button" className="btn btn-ghost" onClick={closeBook}>Cancel</button>
                  <button type="submit" className="btn btn-primary">
                    Confirm & Pay
                    <Icon name="arrow" size={14} />
                  </button>
                </div>
              </form>
            </>
          )}
          {booking && submitted && (
            <div className="wk-modal-success">
              <div className="wk-modal-success-mark">✿</div>
              <h3>Your seat is saved.</h3>
              <p className="wk-modal-sub" style={{maxWidth:'40ch',margin:'8px auto 24px'}}>
                A gentle confirmation with the cafe address and everything to expect is on its way to your inbox and WhatsApp.
              </p>
              <button className="btn btn-primary" onClick={closeBook} style={{margin:'0 auto'}}>
                Back to workshops
                <Icon name="arrow" size={14} />
              </button>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
window.WorkshopsPage = WorkshopsPage;
