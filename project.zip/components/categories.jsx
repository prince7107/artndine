function Categories() {
  const cats = [
    {
      tag: "Best seller",
      title: "Tote Bag Painting",
      desc: "Hand-paint a canvas tote with botanicals or freeform designs. Our most-loved starter workshop.",
      price: "₹899",
      dur: "2 hrs",
      img: "assets/img/hero-tote.jpg",
    },
    {
      tag: "New",
      title: "Cap Painting",
      desc: "Turn a plain cotton cap into a wearable little painting. Perfect for gifting or keeping.",
      price: "₹749",
      dur: "1.5 hrs",
      img: "assets/img/hero-cap.jpg",
    },
    {
      tag: "Beginner",
      title: "Badge & Pin Making",
      desc: "Illustrate, cut, press. Take home a set of six original badges — no drawing skill needed.",
      price: "₹599",
      dur: "1.5 hrs",
      img: "assets/img/hero-badges.jpg",
    },
    {
      tag: "Popular",
      title: "Canvas Art",
      desc: "Learn simple watercolor botanicals on a small stretched canvas. Framed and ready to hang.",
      price: "₹999",
      dur: "2.5 hrs",
      img: "assets/img/cat-canvas.jpg",
    },
    {
      tag: "Slow craft",
      title: "Journal Making",
      desc: "Bind your own softcover journal with pressed flowers and hand-lettered covers.",
      price: "₹1,199",
      dur: "3 hrs",
      img: "assets/img/cat-journal.jpg",
    },
    {
      tag: "Quick session",
      title: "Bookmarks & DIY",
      desc: "Small hand-painted wooden bookmarks with dried florals. A gentle first workshop.",
      price: "₹499",
      dur: "1 hr",
      img: "assets/img/gal-bookmark.jpg",
    },
  ];

  return (
    <section id="categories" className="categories wrap">
      <div className="section-head">
        <div className="reveal">
          <div className="eyebrow">Workshops</div>
          <h2 className="section-title" style={{marginTop:16}}>
            Choose what <em>your hands</em> feel like making today.
          </h2>
        </div>
        <p className="section-lede reveal reveal-delay-1">
          Six workshop formats, each designed for absolute beginners. Come alone, bring a friend, or book a whole table. We provide every material — you just bring yourself.
        </p>
      </div>

      <div className="cat-grid">
        {cats.map((c, i) => (
          <a href="workshops.html" key={c.title} className={`cat-card reveal reveal-delay-${(i % 3) + 1}`}>
            <div className="cat-media">
              <img src={c.img} alt={c.title} />
            </div>
            <span className="cat-tag">{c.tag}</span>
            <h3 className="cat-title">{c.title}</h3>
            <p className="cat-desc">{c.desc}</p>
            <div className="cat-meta">
              <span className="cat-price">{c.price}</span>
              <span className="cat-duration">
                <Icon name="clock" size={14} /> {c.dur}
              </span>
            </div>
          </a>
        ))}
      </div>
    </section>
  );
}
window.Categories = Categories;
