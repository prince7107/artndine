function Nav() {
  const links = [
    { label: "Our Story", href: "#story" },
    { label: "Workshops", href: "#categories" },
    { label: "Gallery", href: "#gallery" },
    { label: "Upcoming", href: "#upcoming" },
    { label: "FAQ", href: "#faq" },
    { label: "Contact", href: "#contact" },
  ];
  return (
    <nav className="nav">
      <a href="#" className="nav-brand">
        <span className="nav-brand-mark" />
        Art &amp; Dine
      </a>
      <div className="nav-links">
        {links.map(l => (
          <a key={l.href} href={l.href} className="nav-link">{l.label}</a>
        ))}
      </div>
      <a href="workshops.html" className="nav-cta">Book a seat</a>
    </nav>
  );
}
window.Nav = Nav;
