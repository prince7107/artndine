function Gallery() {
  const items = [
    { src: "assets/img/gal-group.jpg", cap: "Sunday sessions" },
    { src: "assets/img/gal-tote.jpg", cap: "Finished tote" },
    { src: "assets/img/gal-palette.jpg", cap: "The mess we love" },
    { src: "assets/img/hero-tote.jpg", cap: "Two hands, one canvas" },
    { src: "assets/img/gal-bookmark.jpg", cap: "Tiny details" },
    { src: "assets/img/cat-canvas.jpg", cap: "Watercolor botanicals" },
    { src: "assets/img/gal-pins.jpg", cap: "Take-home badges" },
    { src: "assets/img/gal-cafe.jpg", cap: "Studio corner" },
    { src: "assets/img/hero-cap.jpg", cap: "Cap in progress" },
    { src: "assets/img/cat-journal.jpg", cap: "Journal day" },
    { src: "assets/img/story-studio.jpg", cap: "The little shelf" },
    { src: "assets/img/hero-badges.jpg", cap: "Pin flatlay" },
  ];
  return (
    <section id="gallery" className="gallery wrap">
      <div className="section-head">
        <div className="reveal">
          <div className="eyebrow">Gallery</div>
          <h2 className="section-title" style={{marginTop:16}}>
            Little afternoons, <em>saved.</em>
          </h2>
        </div>
        <p className="section-lede reveal reveal-delay-1">
          A few frames from recent workshops. Also on{' '}
          <a href="https://www.instagram.com/artndinegzb" style={{borderBottom:'1px solid currentColor', paddingBottom:2}}>@artndinegzb</a>.
        </p>
      </div>
      <div className="masonry">
        {items.map((it, i) => (
          <figure key={i} className="masonry-item reveal">
            <img src={it.src} alt={it.cap} loading="lazy" />
            <figcaption className="masonry-item-cap">{it.cap}</figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}
window.Gallery = Gallery;
