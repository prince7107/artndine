function Upcoming() {
  const events = [
    {
      day: "03", month: "Aug",
      title: "Sunday Tote Painting — Botanicals",
      cafe: "Cafe Ivy, Raj Nagar",
      time: "3:00 – 5:00 PM",
      seats: 8,
      price: "₹899",
      status: "3 seats left"
    },
    {
      day: "10", month: "Aug",
      title: "Watercolor Canvas — For Beginners",
      cafe: "The Reading Room, Kavi Nagar",
      time: "4:00 – 6:30 PM",
      seats: 10,
      price: "₹999",
      status: "6 seats left"
    },
    {
      day: "17", month: "Aug",
      title: "Journal Making with Pressed Flowers",
      cafe: "Cafe Ivy, Raj Nagar",
      time: "2:30 – 5:30 PM",
      seats: 10,
      price: "₹1,199",
      status: "Almost full · 2 seats"
    },
    {
      day: "24", month: "Aug",
      title: "Cap Painting — Independence Day Special",
      cafe: "Brew Cafe, Vaishali",
      time: "4:00 – 5:30 PM",
      seats: 12,
      price: "₹749",
      status: "Filling fast"
    },
  ];
  return (
    <section id="upcoming" className="wrap" style={{padding: '80px 0 60px'}}>
      <div className="section-head">
        <div className="reveal">
          <div className="eyebrow">Upcoming</div>
          <h2 className="section-title" style={{marginTop:16}}>
            The next few <em>afternoons.</em>
          </h2>
        </div>
        <p className="section-lede reveal reveal-delay-1">
          We host weekly workshops across cafes in Ghaziabad. Seats are small on purpose — book early.
        </p>
      </div>

      <div className="upcoming-list">
        {events.map((e, i) => (
          <div key={i} className={`upcoming-card reveal reveal-delay-${(i % 3) + 1}`}>
            <div className="upcoming-date">
              <div className="upcoming-date-day">{e.day}</div>
              <div className="upcoming-date-month">{e.month}</div>
            </div>
            <div className="upcoming-content">
              <h3>{e.title}</h3>
              <div className="upcoming-meta">
                <span><Icon name="location" size={14} /> {e.cafe}</span>
                <span><Icon name="clock" size={14} /> {e.time}</span>
                <span><Icon name="users" size={14} /> {e.seats} seats</span>
              </div>
            </div>
            <div className="upcoming-cta">
              <div className="upcoming-price">{e.price}</div>
              <button className="upcoming-btn">Book seat</button>
              <div className="upcoming-seats">{e.status}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
window.Upcoming = Upcoming;
