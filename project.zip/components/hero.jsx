function Hero() {
  return (
    <section className="hero wrap">
      {/* Decorative leaves */}
      <svg className="deco-leaf hero-leaf-1" viewBox="0 0 100 100">
        <path d="M20 80 C 20 40, 60 20, 90 15 C 80 45, 50 75, 20 80 Z" fill="currentColor" opacity="0.6"/>
        <path d="M20 80 L 90 15" stroke="currentColor" strokeWidth="0.8" fill="none"/>
      </svg>
      <svg className="deco-leaf hero-leaf-2" viewBox="0 0 100 100">
        <path d="M80 20 C 80 60, 40 80, 10 85 C 20 55, 50 25, 80 20 Z" fill="currentColor" opacity="0.55"/>
      </svg>

      <div className="hero-grid">
        <div>
          <div className="eyebrow hero-eyebrow">Slow craft, warm light · Ghaziabad</div>
          <h1 className="hero-title">
            Where quiet<br/>
            afternoons<br/>
            become <em>art.</em>
          </h1>
          <p className="hero-sub">
            Beginner-friendly art workshops for people who want to slow down and make something with their hands. Paint a tote, sketch a journal, hand-letter a bookmark — over chai, in the softest corners of Ghaziabad.
          </p>
          <div className="hero-ctas">
            <a href="#upcoming" className="btn btn-primary">
              See upcoming workshops
              <Icon name="arrow" size={16} style={{marginLeft: 2}} />
            </a>
            <a href="workshops.html" className="btn btn-ghost">
              Browse all workshops
            </a>
          </div>
          <div className="hero-stats">
            <div>
              <div className="hero-stat-num">2,400+</div>
              <div className="hero-stat-label">artists hosted</div>
            </div>
            <div>
              <div className="hero-stat-num">12</div>
              <div className="hero-stat-label">workshop formats</div>
            </div>
            <div>
              <div className="hero-stat-num">4.9<span style={{fontSize:'1.2rem', opacity:0.6}}>★</span></div>
              <div className="hero-stat-label">from 380+ reviews</div>
            </div>
          </div>
        </div>

        <div className="hero-collage" aria-hidden="true">
          <div className="polaroid polaroid-1">
            <span className="polaroid-tape" />
            <img src="assets/img/hero-cap.jpg" alt="" />
            <div className="polaroid-cap">cap day ✿</div>
          </div>
          <div className="polaroid polaroid-2">
            <span className="polaroid-tape" />
            <img src="assets/img/hero-tote.jpg" alt="" />
            <div className="polaroid-cap">tote painting</div>
          </div>
          <div className="polaroid polaroid-3">
            <span className="polaroid-tape" />
            <img src="assets/img/hero-badges.jpg" alt="" />
            <div className="polaroid-cap">little things</div>
          </div>
        </div>
      </div>
    </section>
  );
}
window.Hero = Hero;
